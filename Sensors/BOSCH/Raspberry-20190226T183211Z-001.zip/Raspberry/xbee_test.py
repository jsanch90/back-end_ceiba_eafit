
import serial
import time
import math

import json
import requests  

url = 'http://iot.dis.eafit.edu.co/Thingworx/Things/EstacionSolar/Properties/*'
headers = {
    'Content-Type': 'application/json',
    'appkey': 'd9de09c1-fcaa-47a6-a2cb-568248dd2102',
    'Accept': 'application/json',
    'x-thingworx-session': 'true',
    'Cache-Control': 'no-cache',
}

#usb-FTDI_FT232R_USB_UART_A1017HMO-if00-port0

ser = serial.Serial("/dev/serial/by-id/usb-FTDI_FT232R_USB_UART_A1017HMO-if00-port0",baudrate = 9600) 
error = 0
ser.close()
time.sleep(0.5)
ser.open()
dLength = 21
data1=[0]*dLength
data2=[0]*dLength
xdkH={'gyroX':0,
      'gyroY': 0,
      'gyroZ': 0}
xdkL={'light':0,
      'airPress':0,
      'temp':0,
      'humidity':0}

esPowerData = {'generationCurr':0,
               'batteryVoltage':0
               }

lastTime1 = time.time()
lastTime2 = time.time()
lastTime3 = time.time()
debug = False
gyroXval = 0
gyroYval = 0
gyroZval = 0

def bytes2int(bytes):
    result = 0
    
    bytes = reversed(bytes)
    
    for b in bytes:
        result = result*256 + int(b)
    return result

def toSigned(val):
    if val<32768:
        return val
    else:
        val = val-65535
    return val

def map(x,  in_min,  in_max,  out_min,  out_max):
    return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;

def getCurrent(val):
    voltage = map(val, 0,1023,0,3.29)
    current= (voltage-1.645)/0.02
    return current

def readHighData(data1):
    xdkH['accX']= toSigned(bytes2int(data1[0:2]))/100.0
    xdkH['accY']= toSigned(bytes2int(data1[2:4]))/100.0
    xdkH['accZ']= toSigned(bytes2int(data1[4:6]))/100.0
    xdkH['gyroX'] = toSigned(bytes2int(data1[6:8]))/10.0
    xdkH['gyroY'] = toSigned(bytes2int(data1[8:10]))/10.0
    xdkH['gyroZ'] = toSigned(bytes2int(data1[10:12]))/10.0
    return xdkH

def readLowData(data2):
    if int(data2[0])==1:
        xdkL['light'] = toSigned(bytes2int(data2[1:5]))/1000.0
        #xdkL['noise'] = int(data2[5])*1.0
        xdkL['airPress'] = toSigned(bytes2int(data2[6:10]))/100.0
        xdkL['temp'] = bytes2int(data2[10:14])/1000.0
        xdkL['humidity'] = toSigned(bytes2int(data[14:18]))*1.0
        
    elif int(data2[0])==2:
        xdkL['magnX'] = toSigned(bytes2int(data2[1:3]))/1000.0
        xdkL['magnY'] = toSigned(bytes2int(data2[3:5]))/1000.0
        xdkL['magnZ'] = toSigned(bytes2int(data2[5:7]))/1000.0
        xdkL['magnRes'] = toSigned(bytes2int(data2[7:9]))
        
    else:
        print("Message not Recognized")
    return xdkL

def readESpower(data3):
    esPowerData['generationCurr'] = getCurrent(bytes2int(data3[0:2]))
    esPowerData['consumptionCurr'] = getCurrent(bytes2int(data3[2:4]))
    esPowerData['batteryVoltage'] = getCurrent(bytes2int(data3[4:6]))
    return esPowerData
    
def calculateGyro(x,y,z,gyroXval,gyroYval,gyroZval):
    gyroXval = gyroXval + x
    gyroYval = gyroYval + y
    gyroZval = gyroZval + z
    gyroMagn = math.sqrt((gyroXval**2)+(gyroYval**2)+(gyroZval**2))
    return gyroXval,gyroYval,gyroZval, gyroMagn

def post(data, url, headers):
    response = requests.put(url , headers=headers, json=data)
    return response.status_code

def postDB(data):
    url ='https://charging-station.herokuapp.com/api'
    response = requests.post(url , json=data)
    return response.status_code

while True :
    responseCode = 0
    dataRead=0
    data = ser.read(dLength)
    ser.flush()
    #print(data)
    if chr(data[-1]) == 'H':   
        data1=data
        xdkH = readHighData(data1)
        dataRead = 1
        if debug:
            print(xdkH)
            print(" ")
        
    if chr(data[-1]) == 'L':
        data2 = data
        xdkL = readLowData(data2)
        dataRead = 1        
        if debug:            
            print(xdkL)
            
    if chr(data[-1]) == 'C':
        data3 = data
        ES_power = readESpower(data3)
        dbValues = {"light": xdkL['light'],
                    "airPress": xdkL["airPress"],
                    "temp":xdkL["temp"],
                    "humidity": xdkL["humidity"],
                    "current":  ES_power["generationCurr"],
                    "voltage" : ES_power["batteryVoltage"],
                    "currentC" : ES_power["consumptionCurr"]                  
                      }
        dataRead = 1
        
        if debug:
            print(ES_power)
            print(" ")
            
    
    
            
    if dataRead == 1:    
        if time.time()-lastTime1 > 120:
            lastTime1 = time.time()
            responseCode = post(xdkL,url, headers)
            responseCode2 = post(ES_power,url,headers)
            if responseCode == 200:
                print("XDK Low Priority posted succesfully")
                #xdkL={}
                if responseCode2 ==200 :
                    print("Power Values posted succesfully")
            else:
                print("Los datos no fueron posteados en el servidor")
                
        if time.time()-lastTime2 > 10:
            lastTime2 = time.time()
            responseCode = post(xdkH,url, headers)
            if responseCode == 200:
                print("XDK High Priority posted succesfully")
                #xdkH={}
            else:
                print("Los datos no fueron posteados en el servidor")
                
        if time.time()-lastTime3 > 600:
            responseCode = 0
            lastTime3 = time.time()
            responseCode1 = postDB(dbValues)
            
            if responseCode == 200:
                print("MONGO DB posted succesfully")
                xdkH={}
            else:
                print("Los datos no fueron posteados en MongoDB")
    else:
        print("No data to be sent")
        if data[-1]!= 'H' and data[-1]!= 'L' and data[-1]!= 'C':
            print("DataStream not syncronized")
            print("Disconnecting")
            ser.close()
            time.sleep(0.5)
            print("Reconnecting")
            ser.open()
       # prinm serial")
       # ser.close()
       # time.sleep(1.1)
        
       # print ("Reconnecting")
       # ser.open()
            #gyroXval,gyroYval,gyroZval,gyroMag = calculateGyro(xdkH['gyroX'], xdkH['gyroY'],xdkH['gyroZ'],gyroXval,gyroYval,gyroZval)    
    #print(gyroXval/1000,xdkH['gyroX'])
      