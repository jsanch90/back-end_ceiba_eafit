/*
* Licensee agrees that the example code provided to Licensee has been developed and released by Bosch solely as an example to be used as a potential reference for Licensee�s application development. 
* Fitness and suitability of the example code for any use within Licensee�s applications need to be verified by Licensee on its own authority by taking appropriate state of the art actions and measures (e.g. by means of quality assurance measures).
* Licensee shall be responsible for conducting the development of its applications as well as integration of parts of the example code into such applications, taking into account the state of the art of technology and any statutory regulations and provisions applicable for such applications. Compliance with the functional system requirements and testing there of (including validation of information/data security aspects and functional safety) and release shall be solely incumbent upon Licensee. 
* For the avoidance of doubt, Licensee shall be responsible and fully liable for the applications and any distribution of such applications into the market.
* 
* 
* Redistribution and use in source and binary forms, with or without 
* modification, are permitted provided that the following conditions are 
* met:
* 
*     (1) Redistributions of source code must retain the above copyright
*     notice, this list of conditions and the following disclaimer. 
* 
*     (2) Redistributions in binary form must reproduce the above copyright
*     notice, this list of conditions and the following disclaimer in
*     the documentation and/or other materials provided with the
*     distribution.  
*     
*     (3)The name of the author may not be used to
*     endorse or promote products derived from this software without
*     specific prior written permission.
* 
*  THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR 
*  IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
*  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
*  DISCLAIMED. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT,
*  INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
*  (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
*  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
*  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
*  STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
*  IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
*  POSSIBILITY OF SUCH DAMAGE.
*/
/*----------------------------------------------------------------------------*/

/**
* @ingroup VIRTUAL_XDK_DEMO
*
* @defgroup LEMSENSOR LemSensor
* @{
*
* @brief Lem-Sensor signal sampling
* @details This module samples the ADC5 & ADC6 channels and calculates the RMS voltage which is updated on the window period configured
* by the SAMPLING_WINDOW_CYCLES
*
* @file
**/
#include "XDKAppInfo.h"

#undef BCDS_MODULE_ID  /* Module ID define before including Basics package*/
#define BCDS_MODULE_ID XDK_APP_MODULE_ID_LEM_SENSOR
/* Initialization of the ADC */
#include <math.h>
#include "LemSensor.h"
#include "BSP_BoardType.h"
#include "FreeRTOS.h"
#include "BCDS_Assert.h"
#include "task.h"
#include "timers.h"
#include "semphr.h"
#include "BCDS_MCU_Timer.h"
#include "BCDS_MCU_Timer_Handle.h"
#include "em_adc.h"
#include "em_dma.h"
#include "em_gpio.h"

/* Put the type and macro definitions here */
#define TIMEBASE                        UINT32_C(0)             /**< Macro used to define the Timebase for the ADC */
#define SIGNAL_FREQ                     UINT32_C(50)
#define SAMPLING_WINDOW_CYCLES          UINT32_C(10)              /**< Number of cycles signal is sampled for RMS calculation update */
#define ADCFREQUENCY                    UINT32_C(8000000)       /**< Macro Used to define the frequency of the ADC Clock */
#define TIMER_SAMPLING_FREQ             UINT32_C(500)            /**< ADC Signal sampling frequency in Hz */
#define ADC_SAMPLES_IN_RMS_WINDOW       ((TIMER_SAMPLING_FREQ/SIGNAL_FREQ) * SAMPLING_WINDOW_CYCLES)

#define TRANSFORMATION_RATIO        44.44f                  /**< Transformation ratio of the sesor used */

#define DMA_CHANNEL_ADC             4

#define RTC_COMPARE_CHANNEL      UINT32_C(0) /** RTC timer channel selected.  */
#define LFRCO_FREQUENCY          UINT32_C(32768)/**frequency is 32.7KHz  */
#define WAKEUP_INTERVAL_MS       (1000/TIMER_SAMPLING_FREQ) /**wake up interval of the timer is 2 ms  */
#define RTC_COUNT_BETWEEN_WAKEUP ((LFRCO_FREQUENCY * WAKEUP_INTERVAL_MS) / 1000)/**RTC timer count between wakeup  */

struct Buffer_S
{
    uint32_t length;
    uint16_t data[ADC_SAMPLES_IN_RMS_WINDOW * 2]; /* To accommodate both ADC channel sampling */
};

typedef struct Buffer_S Buffer_T, *BufferPtr_T;

Buffer_T PingBuffer = { 0 }; /**< Buffer to hold the ADC samples */
Buffer_T PongBuffer = { 0 }; /**< Buffer to hold the ADC samples */

static Timer_T RtcHandle = 0;
float RMSVoltage = 0.0f;  /**< RMS Voltage on Ch5 */
BufferPtr_T ActiveBuffer = &PingBuffer;
BufferPtr_T BackupBuffer = &PongBuffer;
TaskHandle_t RunningAverageTaskHandle = NULL;

/* DMA callback structure */
DMA_CB_TypeDef cb;

#if DEBUG_LOGGING
static TickType_t xLastWakeTime;
#endif

static volatile xSemaphoreHandle AdcDmaCompleteSync = NULL;

/**
 * @brief Timer callback function to start the ADC sampling
 *
 * On this function callback ADC is triggered to sample the LEM sensor signals on ADC5 & ADC6 channels
 */

static void ADCTriggerTimerCallback(Timer_T timer, struct MCU_Timer_Event_S event)
{
    Retcode_T retVal = RETCODE_OK;
    uint32_t countervalue = 0;
    if (event.CompareChannel & (1 << RTC_COMPARE_CHANNEL))
    {
        if (event.CompareMatch)
        {
            /* Start the ADC */
            ADC_Start(ADC0, ADC_CMD_SCANSTART);
            retVal = MCU_Timer_GetCompareValue(timer, RTC_COMPARE_CHANNEL, &countervalue);
            if (RETCODE_OK == retVal)
            {
                retVal = MCU_Timer_SetCompareValue(timer, RTC_COMPARE_CHANNEL, RTC_COUNT_BETWEEN_WAKEUP + countervalue);
            }
            else
            {
                printf("Timer comparator not set properly \n\r");
            }
        }
    }
}

/**
 * @brief function to activate & enable the DMA for the configured ADC.
 */
static void startDMA(void)
{
    DMA_ActivateBasic(DMA_CHANNEL_ADC, true, false, (void*) ActiveBuffer->data, (void*) &(ADC0->SCANDATA), (ADC_SAMPLES_IN_RMS_WINDOW*2) - 1);
    DMA_ChannelEnable(DMA_CHANNEL_ADC, true);
}

/**
 * @brief Function configures the timer to generate a periodic interrupt on compare value
 *
 */
static Retcode_T configureTimer(void)
{
    Retcode_T retVal;
    RtcHandle = (Timer_T) MCU_Timer_GetRtcHandle();
    retVal = MCU_Timer_Initialize(RtcHandle, ADCTriggerTimerCallback);
    if (RETCODE_OK == retVal)
    {
        retVal = MCU_Timer_SetCompareValue(RtcHandle, RTC_COMPARE_CHANNEL, RTC_COUNT_BETWEEN_WAKEUP);
    }
    return retVal;
}

/**
 * @brief DMA completion interrupt callback for the ADC
 */
static void transferComplete(unsigned int channel, bool primary, void *user)
{
    BCDS_UNUSED(channel);
    BCDS_UNUSED(primary);
    BCDS_UNUSED(user);
    BaseType_t higherPriorityTaskWoken = pdFALSE;

    if (ActiveBuffer == &PingBuffer)
    {
        ActiveBuffer = &PongBuffer;
        BackupBuffer = &PingBuffer;
    }
    else
    {
        ActiveBuffer = &PingBuffer;
        BackupBuffer = &PongBuffer;
    }
    /* Give Semaphore even in case of transfer errors or Transfer completed */
    if (pdTRUE == xSemaphoreGiveFromISR(AdcDmaCompleteSync, &higherPriorityTaskWoken))
    {
        portYIELD_FROM_ISR(higherPriorityTaskWoken);
    }
}

/**
 * @brief Task which calculates the RMS voltage for the Differential signal from the  AD5 & AD6 channels.
 *
 * @param[in] pvParameters not used.
 */
static void CalculateRunningRMS(void *pvParameters)
{
    BCDS_UNUSED(pvParameters);
    float VoltageCh5;
    float VoltageCh6;
    float Voltage = 0.0f;
    float Sum_of_squares = 0.0f;
    uint32_t sumCH1 = 0;
    uint32_t sumCH2 = 0;

    for (;;)
    {
#if  DEBUG_LOGGING
        xLastWakeTime = xTaskGetTickCount();
#endif
        if (pdTRUE == xSemaphoreTake(AdcDmaCompleteSync, portMAX_DELAY))
        {
            /* Activate DMA for sampling */
            startDMA();
            sumCH1 = 0;
            sumCH2 = 0;
            Sum_of_squares = 0;

            for (uint32_t counter = 0; counter < (ADC_SAMPLES_IN_RMS_WINDOW*2); counter += 2)
            {
                sumCH1 = BackupBuffer->data[counter];
                sumCH2 = BackupBuffer->data[counter + 1];
                VoltageCh5 = (float) ((sumCH1 * 1.25f) / (4095.0f)); /* Converting ADC Value to Voltage */
                VoltageCh6 = (float) ((sumCH2 * 1.25f) / (4095.0f)); /* Converting ADC Value to Voltage */
                Voltage = VoltageCh6 - VoltageCh5; /* Calculate the differential Voltage */
                Sum_of_squares += (Voltage * Voltage); /* Calculation the Sqaure of the voltages */
            }
            memset(BackupBuffer->data, UINT8_C(0), (ADC_SAMPLES_IN_RMS_WINDOW*2));
            RMSVoltage = sqrt(Sum_of_squares / ADC_SAMPLES_IN_RMS_WINDOW);
#if  DEBUG_LOGGING
            printf("Lem Sensor Voltage: %f \n\r", RMSVoltage);
            printf("Time difference is %d \n\r ", xTaskGetTickCount() - xLastWakeTime);
#endif
        }
    }
}
/**
 * @brief function to initialize the ADC5 & ADC6 channels in scan mode with required resolution & sampling rate.
 */
static void scanAdcInit(void)
{
    /*Initialize Configuration ADC Structures*/
    ADC_Init_TypeDef adc0_init_conf = ADC_INIT_DEFAULT;
    ADC_InitScan_TypeDef adc0_scaninit_conf = ADC_INITSCAN_DEFAULT;

    /*Enable Clocks for the ADC */
    CMU_ClockEnable(cmuClock_HFPER, true);
    CMU_ClockEnable(cmuClock_ADC0, true);

    /* Configure the ADC Initialization Structure*/
    adc0_init_conf.timebase = ADC_TimebaseCalc(TIMEBASE);
    adc0_init_conf.prescale = ADC_PrescaleCalc(ADCFREQUENCY, TIMEBASE);
    adc0_init_conf.ovsRateSel = adcOvsRateSel2;
    adc0_init_conf.warmUpMode = adcWarmupKeepADCWarm;
    ADC_Init(ADC0, &adc0_init_conf);

    /* Configure the ADC Scan Structure*/
    adc0_scaninit_conf.reference = adcRef1V25;
    adc0_scaninit_conf.input = ADC_SCANCTRL_INPUTMASK_CH5 | ADC_SCANCTRL_INPUTMASK_CH6;
    adc0_scaninit_conf.rep = false;
    adc0_scaninit_conf.prsEnable = false;
    adc0_scaninit_conf.acqTime = adcAcqTime8;
    ADC_InitScan(ADC0, &adc0_scaninit_conf);
}

/**
 * @brief function to configure & initialize the DMA for ADC CH5 & CH6
 */
static void ConfigureDMA(void)
{
    AdcDmaCompleteSync = xSemaphoreCreateBinary();

    if (xTaskCreate(CalculateRunningRMS, "CalculateRunningRMSTASK",
            configMINIMAL_STACK_SIZE, NULL, 3, &RunningAverageTaskHandle) != pdTRUE)
    {
        printf("Running average task cannot be created \r\n");
        assert(false);
    }
    /*Initialize Configuration DMA Structures*/
    DMA_CfgChannel_TypeDef dma_channel_conf;
    DMA_CfgDescr_TypeDef dma_descr_conf;

    /*Enable clock for the DMA*/
    CMU_ClockEnable(cmuClock_DMA, true);

    /*Setup call-back function*/
    cb.cbFunc = transferComplete;
    cb.userPtr = NULL;

    /*Setup DMA channel*/
    dma_channel_conf.highPri = false;
    dma_channel_conf.enableInt = true;
    dma_channel_conf.select = DMAREQ_ADC0_SCAN;
    dma_channel_conf.cb = &cb;
    DMA_CfgChannel(DMA_CHANNEL_ADC, &dma_channel_conf);

    /*Setup DMA Descriptor*/
    dma_descr_conf.arbRate = dmaArbitrate1;
    dma_descr_conf.dstInc = dmaDataInc2;
    dma_descr_conf.hprot = 0;
    dma_descr_conf.size = dmaDataSize2;
    dma_descr_conf.srcInc = dmaDataIncNone;
    DMA_CfgDescr(DMA_CHANNEL_ADC, true, &dma_descr_conf);
}

/**
 * @brief function to initialize the LEM extension board connect port pin.
 */
static void initPCBDetection(void)
{
    CMU_ClockEnable(cmuClock_GPIO, true);
    GPIO_PinModeSet(gpioPortE, 2, gpioModeInputPull, 1);
}

/**
 * @brief function to start the timer for periodic ADC sampling.
 *
 * @return   Status of the Getting the Lem sensor start sample.
 *            - RETCODE_OK if the Lem sensor sampling is started successfully.
 *            - Error for failure.
 */
static Retcode_T LemSensorStartSample(void)
{
    Retcode_T returnVal = RETCODE_OK;
    MCU_Timer_Status_T timerStatus = MCU_TIMER_STATUS_IDLE;

    /* DMA start */
    startDMA();
    timerStatus = MCU_Timer_GetStatus(RtcHandle);
    if (MCU_TIMER_STATUS_INITIALIZED == timerStatus)
    {
        returnVal = MCU_Timer_Start(RtcHandle);
    }
    else
    {
        returnVal = RETCODE(RETCODE_SEVERITY_ERROR, (uint32_t)timerStatus);
    }
    return returnVal;
}

/* Refer Interface Header for API documentation */
Retcode_T LemSensorInit(void)
{
    Retcode_T retval = RETCODE_OK;
    /*init LEM PCB detection*/
    initPCBDetection();
    /* init ADC and DMA for LEM Sensor */
    scanAdcInit();
    ConfigureDMA();
    retval = configureTimer();
    if(RETCODE_OK == retval)
    {
        retval = LemSensorStartSample();
    }
    return retval;
}

/* Refer Interface Header for API documentation */
uint8_t LemSensorStatus(void)
{
    return !GPIO_PinInGet(gpioPortE, 2);
}

/* Refer Interface Header for API documentation */
Retcode_T LemSensorGetRmsVoltage(float * rmsvoltage)
{
    Retcode_T retval = RETCODE_OK;
    if(NULL == rmsvoltage)
    {
        retval = RETCODE(RETCODE_SEVERITY_ERROR, RETCODE_NULL_POINTER);
    }
    else
    {
        *rmsvoltage =  RMSVoltage;
    }
    return retval;
}

