/*
* Licensee agrees that the example code provided to Licensee has been developed and released by Bosch solely as an example to be used as a potential reference for Licensee�s application development. 
* Fitness and suitability of the example code for any use within Licensee�s applications need to be verified by Licensee on its own authority by taking appropriate state of the art actions and measures (e.g. by means of quality assurance measures).
* Licensee shall be responsible for conducting the development of its applications as well as integration of parts of the example code into such applications, taking into account the state of the art of technology and any statutory regulations and provisions applicable for such applications. Compliance with the functional system requirements and testing there of (including validation of information/data security aspects and functional safety) and release shall be solely incumbent upon Licensee. 
* For the avoidance of doubt, Licensee shall be responsible and fully liable for the applications and any distribution of such applications into the market.
* 
* 
* Redistribution and use in source and binary forms, with or without 
* modification, are permitted provided that the following conditions are 
* met:
* 
*     (1) Redistributions of source code must retain the above copyright
*     notice, this list of conditions and the following disclaimer. 
* 
*     (2) Redistributions in binary form must reproduce the above copyright
*     notice, this list of conditions and the following disclaimer in
*     the documentation and/or other materials provided with the
*     distribution.  
*     
*     (3)The name of the author may not be used to
*     endorse or promote products derived from this software without
*     specific prior written permission.
* 
*  THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR 
*  IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
*  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
*  DISCLAIMED. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT,
*  INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
*  (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
*  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
*  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
*  STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
*  IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
*  POSSIBILITY OF SUCH DAMAGE.
*/
/*----------------------------------------------------------------------------*/
/**
 * @ingroup APPS_LIST
 *
 * @defgroup VIRTUAL_XDK_DEMO Virtual XDK Demo
 * @{
 *
 * @brief Demo Application for Virtual XDK mobile application
 *
 * @details In this application, XDK is presented in a playful fashion on a mobile device that is connected to XDK via BLE.
 * Interacting with the physical XDK will manipulate the virtual XDK.
 *
 * The web links to get the Android/iOS App is given below:<br>
 * <b> Android App: </b> <a href="https://play.google.com/store/apps/details?id=com.bosch.VirtualXdk">Click_Here</a> <br>
 * <b> iOS App: </b> <a href="https://itunes.apple.com/de/app/virtual-xdk/id1120568347?mt=8">Click_Here</a> <br>
 * For further documentation please refer the page \ref XDK_VIRTUAL_XDK_APP_USER_GUIDE
 *
 * @file
 **/

/* module includes ********************************************************** */
#include "XDKAppInfo.h"

#undef BCDS_MODULE_ID  /* Module ID define before including Basics package*/
#define BCDS_MODULE_ID XDK_APP_MODULE_ID_VIRTUAL_XDK

/* own header files */
#include "VirtualXdkDemo.h"

#if LEMSENSOR_ENABLE
#include "LemSensor.h"
#endif

/* system header files */
#include <stdio.h>

/* additional interface header files */
#include "XdkSensorHandle.h"
#include "BCDS_Basics.h"
#include "BCDS_Assert.h"
#include "BCDS_Ble.h"
#include "BCDS_BlePeripheral.h"
#include "BCDS_SensorServices.h"
#include "BCDS_SDCard_Driver.h"
#include "BCDS_SensorErrorType.h"
#include "BCDS_BSP_LED.h"
#include "BCDS_BSP_Board.h"
#include "BCDS_BSP_Button.h"
#include "BSP_BoardType.h"
#include "em_gpio.h"
#include "BCDS_CmdProcessor.h"
#include "portmacro.h"
#include "FreeRTOS.h"
#include "timers.h"
#include "semphr.h"

/* constant definitions ***************************************************** */
#define LED_ORANGE_PIN                                                      (1)
#define LED_ORANGE_PORT                                                     (gpioPortB)

#define LED_RED_PIN                                                         (12)
#define LED_RED_PORT                                                        (gpioPortA)
#define LED_YELLOW_PIN                                                      (0)
#define LED_YELLOW_PORT                                                     (gpioPortB)

#if LEMSENSOR_ENABLE
#define VOLTS_TO_MICROVOLTS                                                 UINT32_C(1000000)
#endif

/* global variables ********************************************************* */

/* semaphore unblocking completion of frame transmission*/
static SemaphoreHandle_t SendCompleteSync = NULL;
static xTimerHandle highDataRateSampleTimerHandle = 0; /** variable to store timer handle for the gyro sensor sample time */
static uint32_t highDataRateSampleTime = 200; /** variable to store the sensor sample time */
static uint16_t sampleCounter = 0; /** counter used for toggling low prio data messages  */
static CmdProcessor_T* AppCmdProcessor; /**< Application Command Processor Instance */
static volatile uint8_t button1Status = 0;
static volatile uint8_t button2Status = 0;
uint8_t isUseBuiltInSensorFusion = 1;
static BlePeripheral_Event_T connectionStatus = BLE_PERIPHERAL_DISCONNECTED;
static SemaphoreHandle_t BleStartSyncSemphr = NULL;
static SemaphoreHandle_t BleWakeUpSyncSemphr = NULL;

#if !ENABLE_HIGH_PRIO_DATA_SERVICE
static xTimerHandle sensorSampleTimerHandle = 0;/**< variable to store timer handle for the sensor sample time*/
static uint32_t sensorSampleTime = 2000; /** variable to store the sensor sample time */
#endif //!ENABLE_HIGH_PRIO_DATA_SERVICE

/* inline functions ********************************************************* */

/* local functions ********************************************************** */

/**
 * @brief This function returns the connection status
 *
 * @retVal Connection status of the device
 */
static BlePeripheral_Event_T GetBleConnectionStatus(void)
{
    return (connectionStatus);
}

/**
 * @brief Function returning the timer handle of the high data rate sampling timer
 * @return The timer handle in question
 */
static xTimerHandle GetHighDataRateTimerHandle(void)
{
    return highDataRateSampleTimerHandle;
}

/**
 * @brief Callback function called on BLE event
 *
 * @param [in]  event : event to be send by BLE during communication.
 *
 * @param [in]  data : void pointer pointing to a data type based on event.
 *
 * -------------------------------------------------------------------------------
 * |                   event                     |   data type                   |
 * -------------------------------------------------------------------------------
 * |    BLE_PERIPHERAL_STARTED                   |   Retcode_T                   |
 * |    BLE_PERIPHERAL_SERVICES_REGISTERED       |   unused                      |
 * |    BLE_PERIPHERAL_SLEEP_SUCCEEDED           |   Retcode_T                   |
 * |    BLE_PERIPHERAL_WAKEUP_SUCCEEDED          |   Retcode_T                   |
 * |    BLE_PERIPHERAL_CONNECTED                 |   Ble_RemoteDeviceAddress_T   |
 * |    BLE_PERIPHERAL_DISCONNECTED              |   Ble_RemoteDeviceAddress_T   |
 * |    BLE_PERIPHERAL_ERROR                     |   Retcode_T                   |
 * -------------------------------------------------------------------------------
 */
static void BleEventCallBack(BlePeripheral_Event_T event, void * data)
{
    BCDS_UNUSED(data);
    Retcode_T retval;
    BlePeripheral_Event_T Event = event;
    switch (Event)
    {
    case BLE_PERIPHERAL_SERVICES_REGISTERED:
        break;
    case BLE_PERIPHERAL_STARTED:
        printf("BLE powered ON successfully \r\n");
        if (xSemaphoreGive(BleStartSyncSemphr) != pdTRUE)
        {
            // We would not expect this call to fail because we must have obtained the semaphore to get here.
            Retcode_RaiseError(RETCODE(RETCODE_SEVERITY_FATAL, SEMAPHORE_GIVE_ERROR));
        }
        break;

    case BLE_PERIPHERAL_SLEEP_SUCCEEDED:
        printf("BLE successfully entered into sleep mode \r\n");
        break;

    case BLE_PERIPHERAL_WAKEUP_SUCCEEDED:
        printf("Device Wake up succceded  : \r\n");
        if (xSemaphoreGive(BleWakeUpSyncSemphr) != pdTRUE)
        {
            // We would not expect this call to fail because we must have obtained the semaphore to get here.
            Retcode_RaiseError(RETCODE(RETCODE_SEVERITY_FATAL, SEMAPHORE_GIVE_ERROR));
        }
        break;

    case BLE_PERIPHERAL_CONNECTED:
        printf("Device connected  : \r\n");
        connectionStatus = BLE_PERIPHERAL_CONNECTED;
        retval = BSP_LED_Switch((uint32_t) BSP_XDK_LED_O, (uint32_t) BSP_LED_COMMAND_ON);
        if (RETCODE_OK != retval)
        {
            printf("Switching ON Orange LED failed : \r\n");
        }
        break;

    case BLE_PERIPHERAL_DISCONNECTED:
        printf("Device Disconnected   : \r\n");
        connectionStatus = BLE_PERIPHERAL_DISCONNECTED;
        retval = BSP_LED_Switch((uint32_t) BSP_XDK_LED_O, (uint32_t) BSP_LED_COMMAND_OFF);
        if (RETCODE_OK != retval)
        {
            printf("Switching OFF Orange LED failed : \r\n");
        }
        /* stop Ble timer accelerometer data transmission timer */
        if (pdTRUE != xTimerStop(GetHighDataRateTimerHandle(), UINT8_C(0)))
        {
            /* Assertion Reason: Failed to start software timer. Check command queue size of software timer service. */
            assert(false);
        }
        break;
    case BLE_PERIPHERAL_ERROR:
        printf("BLE Error Event  : \r\n");
        connectionStatus = BLE_PERIPHERAL_DISCONNECTED;
        /* stop the High data rate timer in-case of BLE Hardware error.  */
        if (pdTRUE != xTimerStop(GetHighDataRateTimerHandle(), UINT8_C(0)))
        {
            /* Assertion Reason: Failed to start software timer. Check command queue size of software timer service. */
            assert(false);
        }
        break;

    default:
        /* assertion reason : invalid status of Bluetooth Device */
        assert(false);
        break;
    }
}

/**
 *  The function to register the Sensors service
 */

static Retcode_T SensorServiceRegistryCallback(void)
{
    Retcode_T retval = RETCODE_OK;
    retval = SensorServices_Register();
    return (retval);
}

/**
 * @brief Set the sensor sampling time for the high data rate service to a new value
 * @param samplingTimer The new sample timer for the high data rate service
 */
static void SetHighDataRateSensorSamplingRate(uint32_t samplingTime)
{
    int8_t retValPerSwTimer = pdFAIL;

    highDataRateSampleTime = samplingTime;
    uint32_t Ticks = highDataRateSampleTime;

    if (Ticks != UINT32_MAX) /* Validated for portMAX_DELAY to assist the task to wait Infinitely (without timing out) */
    {
        Ticks /= portTICK_RATE_MS;
    }
    if (UINT32_C(0) == Ticks) /* ticks cannot be 0 in FreeRTOS timer. So ticks is assigned to 1 */
    {
        Ticks = UINT32_C(1);
    }
    retValPerSwTimer = xTimerChangePeriod(highDataRateSampleTimerHandle, Ticks, portMAX_DELAY);
    if (pdPASS != retValPerSwTimer)
    {
        assert(false);
    }
    else
    {
        printf("Set high data rate sensor sampling timer succesful! \r\n");
    }
}

/**
 * @brief Callback function called on data reception over BLE
 *
 * @param [in]  rxBuffer : Buffer in which received data to be stored.
 *
 * @param [in]  rxDataLength : Length of received data.
 */

static void BleDataReceivedCallBack(uint8_t *rxBuffer, uint8_t rxDataLength, Ble_SensorServicesInfo_T * param)
{
    BCDS_UNUSED(rxDataLength);
    BaseType_t timerRetVal = pdFAIL;

    Ble_SensorServicesInfo_T sensorServiceInfo = *param;
    if ((int) BLE_CONTROL_NODE == sensorServiceInfo.sensorServicesType)
    {
        if ((int) CONTROL_NODE_START_SAMPLING == sensorServiceInfo.sensorServicesContent)
        {
            timerRetVal = xTimerStart(GetHighDataRateTimerHandle(), 0xffff);
            {
                if (pdFAIL == timerRetVal)
                {
                    printf("Start of High priority Sensor Timer Failed %d \r\n", (int) timerRetVal);
                }
                else
                {
                    printf("Start of High priority Sensor Timer succeed %d \r\n", (int) timerRetVal);

                }

            }
        }
        else if ((int) CONTROL_NODE_CHANGE_SAMPLING_RATE == sensorServiceInfo.sensorServicesContent)
        {
            uint32_t receivedSamplingRate = 0;

            uint8_t receiveBuffer[4];

            memset(receiveBuffer, 0, (sizeof(receiveBuffer) / sizeof(uint8_t)));

            receiveBuffer[0] = *(rxBuffer);
            receiveBuffer[1] = *(rxBuffer + 1);

            receiveBuffer[2] = *(rxBuffer + 2);
            receiveBuffer[3] = *(rxBuffer + 3);

            printf("Sampling rate receiveBuffer[0]: %d\r\n", receiveBuffer[0]);
            printf("Sampling rate receiveBuffer[1]: %d\r\n", receiveBuffer[1]);
            printf("Sampling rate receiveBuffer[2]: %d\r\n", receiveBuffer[2]);
            printf("Sampling rate receiveBuffer[3]: %d\r\n", receiveBuffer[3]);

            receivedSamplingRate = receiveBuffer[3];
            receivedSamplingRate = (receivedSamplingRate << 8)
                    + receiveBuffer[2];
            receivedSamplingRate = (receivedSamplingRate << 8)
                    + receiveBuffer[1];
            receivedSamplingRate = (receivedSamplingRate << 8)
                    + receiveBuffer[0];

            printf("New sensor sampling rate received \r\n");
            printf("New sampling rate: %d \r\n", (int) receivedSamplingRate);

            if ((receivedSamplingRate < 200) || (receivedSamplingRate > 5000))
            {
                receivedSamplingRate = 200;
            }

            SetHighDataRateSensorSamplingRate(receivedSamplingRate);
        }
        else if ((int) CONTROL_NODE_REBOOT == sensorServiceInfo.sensorServicesContent)
        {
            printf("Reset request received from App! \r\n");
            BSP_Board_SoftReset();
        }
        else if ((int) CONTROL_NODE_USE_SENSOR_FUSION == sensorServiceInfo.sensorServicesContent)
        {
            isUseBuiltInSensorFusion = *rxBuffer;
        }
    }

}

/** ************************************************************************* */

static void BleSendCallback(Retcode_T sendStatus)
{
    if (RETCODE_OK != sendStatus)
    {
        printf("failed to send the data\r\n");
    }
    if ( xSemaphoreGive( SendCompleteSync ) != pdTRUE)
    {
        // We would not expect this call to fail because we must have obtained the semaphore to get here.
        Retcode_RaiseError(RETCODE(RETCODE_SEVERITY_ERROR, SEMAPHORE_GIVE_ERROR));
    }
}

static void printSensorError(Retcode_T error)
{
    BCDS_SensorErrorType_T returnValue = SENSOR_ERROR;

    returnValue = BCDS_getSensorErrorCode(error);
    if (returnValue == SENSOR_ERROR)
    {
        printf("SENSOR_ERROR\r\n");
    }
    else if (returnValue == SENSOR_INVALID_PARAMETER)
    {
        printf("SENSOR_INVALID_PARAMETER\r\n");
    }
    else if (returnValue == SENSOR_INIT_NOT_DONE)
    {
        printf("SENSOR_INIT_NOT_DONE\r\n");
    }
    else if (returnValue == SENSOR_UNSUPPORTED_PARAMETER)
    {
        printf("SENSOR_UNSUPPORTED_PARAMETER\r\n");
    }
    else
    {
        printf("Unknown sensor error! Error code: %i\r\n", returnValue);
    }
}

static void readAccelerometerData(Accelerometer_XyzData_T* accelData)
{

    Retcode_T accError = (Retcode_T) RETCODE_FAILURE;

    accError = Accelerometer_readXyzLsbValue(xdkAccelerometers_BMA280_Handle, accelData);

    if ( RETCODE_OK == accError)
    {
#if DEBUG_LOGGING
        /*print Accel data of BMA280 on serialport */
        printf("Accel Data Raw Data :\r\nx =%d\r\ny= %d\r\nz =%d\r\n",
                (uint) accelData->xAxisData, (uint) accelData->yAxisData, (uint) accelData->zAxisData);
#endif
    }
    else
    {
        printf("Error reading accelerometer sensor values!\r\n");
        printSensorError(accError);
    }

    accError = Accelerometer_readXyzGValue(xdkAccelerometers_BMA280_Handle, accelData);

    if ( RETCODE_OK == accError)
    {
#if DEBUG_LOGGING
        /*print Accel data of BMA280 on serialport */
        printf("Accel Data G data :\r\nx =%d\r\ny= %d\r\nz =%d\r\n",
                (uint) accelData->xAxisData, (uint) accelData->yAxisData, (uint) accelData->zAxisData);
#endif
    }
    else
    {
        printf("Error reading accelerometer sensor G values!\r\n");
        printSensorError(accError);
    }

}

static void readGyroData(Gyroscope_XyzData_T* gyroData)
{

    Retcode_T gyroError = (Retcode_T) RETCODE_FAILURE;

    gyroError = Gyroscope_readXyzValue(xdkGyroscope_BMG160_Handle, gyroData);

    if ( RETCODE_OK == gyroError)
    {
#if DEBUG_LOGGING
        /*print chip id and gyro data on serialport */
        printf("Gyro Data Raw :\tx =%d\ty= %d\tz =%d\r\n",
                (int) gyroData->xAxisData, (int) gyroData->yAxisData, (int) gyroData->zAxisData);
#endif
    }
    else
    {
        printf("Error reading gyro sensor values!\r\n");
        printSensorError(gyroError);
    }

#if READ_GYRO_VALUES_DEGREE
    gyroError = Gyroscope_readXyzValue(xdkGyroscope_BMG160_Handle, gyroData);
    if (RETCODE_OK ==gyroError )
    {
        /*print chip id and gyro data on serialport */
        printf("Gyro Data Degree :\tx =%d\ty= %d\tz =%d\r\n",
                (int)gyroData->xAxisData, (int)gyroData->yAxisData, (int)gyroData->zAxisData);

    }
    else
    {
        printf("Error reading gyro sensor values!\r\n");
        printSensorError(gyroError);
    }
#endif
}

static void readLightSensor(uint32_t* milliLuxData)
{
    Retcode_T lightSensorError = (Retcode_T) RETCODE_FAILURE;

    /* read sensor data in milli lux*/
    lightSensorError = LightSensor_readLuxData(xdkLightSensor_MAX44009_Handle, milliLuxData);
    if (lightSensorError != RETCODE_OK)
    {
        printf("lightsensorReadInMilliLux Failed\r\n");
        printSensorError(lightSensorError);
    }
    else
    {
#if DEBUG_LOGGING
        printf("sensor data obtained in milli lux :%d \r\n", (unsigned int) milliLuxData);
#endif
    }

}

#if NOISE_SENSOR_ACTIVATED
static void noiseSensorInit(void)
{
    /* initialize the Noise Sensor*/
    AKU_init(&noiseSensor);
}
#endif

static void readNoiseSensor(uint8_t* noiseDbSpl)
{

#if !NOISE_SENSOR_ACTIVATED
    (void) noiseDbSpl;
#endif

#if NOISE_SENSOR_ACTIVATED
    Retcode_T noiseSensorError = (Retcode_T)RETCODE_FAILURE;
    uint32_t sensorData = 0;
    uint32_t sensorDataDb = 0;
    uint8_t sensorDataDbSpl = 0;

    noiseSensorError = AKU_getSensorData(&sensorData);

    if (noiseSensorError == RETCODE_OK)
    {
        /* Converts data from mV to dBSPL*/
        sensorDataDb = (uint32_t) (20 * (log10(sensorData / AKU_SENSITIVITY_VOLT)));

        sensorDataDbSpl = sensorDataDb + AKU_SENSITIVITY_DB + AKU_PASCALTODBSPL - AKU_SENSORGAIN;
        /* print the sensor data */
        printf("sensor data :%d dBSPL\r\n", sensorDataDbSpl);
        memcpy(noiseDbSpl, &sensorDataDbSpl, sizeof(uint8_t));
    }
    else
    {
        printf("AKU_getSensorData failed! \r\n");
        printSensorError(noiseSensorError);
    }
#endif
}

static void readMagnetometerSensor(Magnetometer_XyzData_T* magData)
{
    Retcode_T magnetometerSensorError = (Retcode_T) RETCODE_FAILURE;

    /* read magnetometer sensor data*/

    magnetometerSensorError = Magnetometer_readXyzTeslaData(
            xdkMagnetometer_BMM150_Handle, magData);

    if (magnetometerSensorError != RETCODE_OK)
    {
        printf("magnetometerReadMicroTeslaXyz Failed\r\n");
    }
    else
    {
#if DEBUG_LOGGING
        /*print magnetometer sensor data on serialport */
        printf("Magnetometer micro tesla data :\r\nx =%d\r\ny= %d\r\nz =%d\r\n",
                (int) magData->xAxisData, (int) magData->yAxisData, (int) magData->zAxisData);
        printf("Magnetometer sensor data resistance: %d \r\n\4", (int) magData->resistance);
#endif
    }

}

static void readEnvironmentSensor(Environmental_Data_T* value)
{
    Retcode_T environmentSensorError = (Retcode_T) RETCODE_FAILURE;

    environmentSensorError = Environmental_readData(xdkEnvironmental_BME280_Handle, value);

    if (RETCODE_OK == environmentSensorError)
    {
        environmentSensorError = Environmental_compensateData(xdkEnvironmental_BME280_Handle, value);
    }

    if (RETCODE_OK == environmentSensorError)
    {
#if DEBUG_LOGGING
        /*Environment data on serialport */
        printf("Environmental Conversion Data :\r\n =%ld Pa\r\nt =%ld mDeg\r\nh =%ld %%rh\r\n",
                (long int) value->pressure, (long int) value->temperature, (long int) value->humidity);
#endif
    }
    else
    {
        printf("Error reading environment sensor values!\r\n");
        printSensorError(environmentSensorError);
    }
}

static uint8_t readSdCardStatus(void)
{
    if (SDCARD_INSERTED == SDCardDriver_GetDetectStatus())
    {
#if DEBUG_LOGGING
        printf("SD card is inserted in XDK\r\n");
#endif
        return 1;

    }
    else
    {
#if DEBUG_LOGGING
        printf("SD card is not inserted in XDK\r\n");
#endif
        return 0;
    }
}

static void readRotationValue(Rotation_QuaternionData_T* value)
{
    Retcode_T RotationSensorError = (Retcode_T) RETCODE_FAILURE;

    RotationSensorError = Rotation_readQuaternionValue(value);

    if (RETCODE_OK == RotationSensorError)
    {
        /*orientation data on serialport */
#if DEBUG_LOGGING
        printf("Rotation data : %3.4f, %3.4f, %3.4f, %3.4f\n\r",
                value->w, value->x, value->y, value->z);
#endif
    }
    else
    {
        printf("Error reading Rotation values!\n");
        printSensorError(RotationSensorError);
    }
}

#if !ENABLE_HIGH_PRIO_DATA_SERVICE

static void sampleAndNotifySensorData(void * param1, uint32_t param2)
{
    Retcode_T returnValue = RETCODE_OK;
    BCDS_UNUSED(param1);
    BCDS_UNUSED(param2);

    Ble_SensorServicesInfo_T ServiceInfo;

#if ENABLE_ACCELEROMETER_NOTIFICATIONS
    Accelerometer_XyzData_T accelData;
    readAccelerometerData(&accelData);
    ServiceInfo.sensorServicesContent = (uint8_t) SENSOR_AXIS_X;
    ServiceInfo.sensorServicesType = (uint8_t) BLE_SENSOR_ACCELEROMETER;
    returnValue = SensorServices_SendData((uint8_t *)&accelData.xAxisData, 4, &ServiceInfo);
    if (RETCODE_OK == returnValue)
    {
        if (pdFALSE == xSemaphoreTake(SendCompleteSync, 1000))
        {
            assert(false);
        }
    }
    ServiceInfo.sensorServicesContent = (uint8_t) SENSOR_AXIS_Y;
    returnValue =SensorServices_SendData((uint8_t *)&accelData.yAxisData, 4, &ServiceInfo);
    if (RETCODE_OK == returnValue)
    {
        if (pdFALSE == xSemaphoreTake(SendCompleteSync, 1000))
        {
            assert(false);
        }
    }
    ServiceInfo.sensorServicesContent = (uint8_t) SENSOR_AXIS_Z;
    returnValue =SensorServices_SendData((uint8_t *)&accelData.zAxisData, 4, &ServiceInfo);
    if (RETCODE_OK == returnValue)
    {
        if (pdFALSE == xSemaphoreTake(SendCompleteSync, 1000))
        {
            assert(false);
        }
    }
#endif

#if    ENABLE_GYRO_NOTIFICATIONS
    Gyroscope_XyzData_T gyroData;
    readGyroData(&gyroData);
    ServiceInfo.sensorServicesContent = (uint8_t) SENSOR_AXIS_X;
    ServiceInfo.sensorServicesType = (uint8_t) BLE_SENSOR_GYRO;
    returnValue =SensorServices_SendData((uint8_t *)&gyroData.xAxisData, 4, &ServiceInfo);
    if (RETCODE_OK == returnValue)
    {
        if (pdFALSE == xSemaphoreTake(SendCompleteSync, 1000))
        {
            assert(false);
        }
    }
    ServiceInfo.sensorServicesContent = (uint8_t) SENSOR_AXIS_Y;
    returnValue =SensorServices_SendData((uint8_t *)&gyroData.yAxisData, 4, &ServiceInfo);
    if (RETCODE_OK == returnValue)
    {
        if (pdFALSE == xSemaphoreTake(SendCompleteSync, 1000))
        {
            assert(false);
        }
    }
    ServiceInfo.sensorServicesContent = (uint8_t) SENSOR_AXIS_Z;
    returnValue =SensorServices_SendData((uint8_t *)&gyroData.zAxisData, 4, &ServiceInfo);
    if (RETCODE_OK == returnValue)
    {
        if (pdFALSE == xSemaphoreTake(SendCompleteSync, 1000))
        {
            assert(false);
        }
    }
#endif

#if ENABLE_LIGHT_SENSOR_NOTIFICATIONS
    uint32_t milliLuxData;
    readLightSensor(&milliLuxData);
    ServiceInfo.sensorServicesType = (uint8_t) BLE_SENSOR_LIGHT;
    returnValue =SensorServices_SendData((uint8_t *)&milliLuxData, 4, &ServiceInfo );
    if (RETCODE_OK == returnValue)
    {
        if (pdFALSE == xSemaphoreTake(SendCompleteSync, 1000))
        {
            assert(false);
        }
    }
#endif

#if ENABLE_NOISE_SENSOR_NOTIFICATIONS
    uint8_t noiseDbSpl;
    readNoiseSensor(&noiseDbSpl);
    ServiceInfo.sensorServicesType = (uint8_t) BLE_SENSOR_NOISE;
    returnValue =SensorServices_SendData(&noiseDbSpl, 4, &ServiceInfo );
    if (RETCODE_OK == returnValue)
    {
        if (pdFALSE == xSemaphoreTake(SendCompleteSync, 1000))
        {
            assert(false);
        }
    }
#endif

#if     ENABLE_MAGNETOMETER_NOTIFICATIONS
    Magnetometer_XyzData_T magData;
    readMagnetometerSensor(&magData);
    ServiceInfo.sensorServicesContent = (uint8_t) SENSOR_MAGNETOMETER_AXIS_X;
    ServiceInfo.sensorServicesType = (uint8_t) BLE_SENSOR_MAGNETOMETER;
    returnValue =SensorServices_SendData((uint8_t *)&magData.xAxisData, 4, &ServiceInfo);
    if (RETCODE_OK == returnValue)
    {
        if (pdFALSE == xSemaphoreTake(SendCompleteSync, 1000))
        {
            assert(false);
        }
    }
    ServiceInfo.sensorServicesContent = (uint8_t) SENSOR_MAGNETOMETER_AXIS_Y;
    returnValue =SensorServices_SendData((uint8_t *)&magData.yAxisData, 4, &ServiceInfo);
    if (RETCODE_OK == returnValue)
    {
        if (pdFALSE == xSemaphoreTake(SendCompleteSync, 1000))
        {
            assert(false);
        }
    }
    ServiceInfo.sensorServicesContent = (uint8_t) SENSOR_MAGNETOMETER_AXIS_Z;
    returnValue =SensorServices_SendData((uint8_t *)&magData.zAxisData, 4, &ServiceInfo);
    if (RETCODE_OK == returnValue)
    {
        if (pdFALSE == xSemaphoreTake(SendCompleteSync, 1000))
        {
            assert(false);
        }
    }
    ServiceInfo.sensorServicesContent = (uint8_t) SENSOR_MAGNETOMETER_RESISTANCE;
    returnValue =SensorServices_SendData((uint8_t *)&magData.resistance, 4, &ServiceInfo );
    if (RETCODE_OK == returnValue)
    {
        if (pdFALSE == xSemaphoreTake(SendCompleteSync, 1000))
        {
            assert(false);
        }
    }
#endif

#if ENABLE_ENVIRONMENT_SENSOR_NOTIFICATIONS
    Environmental_Data_T environmentData;
    readEnvironmentSensor(&environmentData);
    ServiceInfo.sensorServicesContent = (uint8_t) SENSOR_ENVIRONMENTAL_PRESSURE;
    ServiceInfo.sensorServicesType = (uint8_t) BLE_SENSOR_ENVIRONMENTAL;
    returnValue =SensorServices_SendData((uint8_t *)&environmentData.pressure, 4, &ServiceInfo );
    if (RETCODE_OK == returnValue)
    {
        if (pdFALSE == xSemaphoreTake(SendCompleteSync, 1000))
        {
            assert(false);
        }
    }
    ServiceInfo.sensorServicesContent = (uint8_t) SENSOR_ENVIRONMENTAL_TEMPERATURE;
    returnValue =SensorServices_SendData((uint8_t *)&environmentData.temperature, 4, &ServiceInfo );
    if (RETCODE_OK == returnValue)
    {
        if (pdFALSE == xSemaphoreTake(SendCompleteSync, 1000))
        {
            assert(false);
        }
    }
    ServiceInfo.sensorServicesContent = (uint8_t) SENSOR_ENVIRONMENTAL_HUMIDITY;
    returnValue =SensorServices_SendData((uint8_t *)&environmentData.humidity, 4, &ServiceInfo );
    if (RETCODE_OK == returnValue)
    {
        if (pdFALSE == xSemaphoreTake(SendCompleteSync, 1000))
        {
            assert(false);
        }
    }
#endif

}
#endif

static void sampleAndNotifyHighPriorityData(void * param1, uint32_t param2)
{
    BCDS_UNUSED(param1);
    BCDS_UNUSED(param2);

#if LEMSENSOR_ENABLE
    float RMSVolt = 0;
    uint32_t RmsuVolt = 0;
#endif

    Accelerometer_XyzData_T accelData;
    Gyroscope_XyzData_T gyroData;
    Retcode_T returnValue = RETCODE_OK;
#if ORIENTATION_SENSOR_USED
    Rotation_QuaternionData_T rotationData;
#endif

    uint32_t milliLuxData;
    uint8_t noiseDbSpl;
    Magnetometer_XyzData_T magData;
    Environmental_Data_T environmentData;
    Ble_SensorServicesInfo_T ServiceInfo;

    uint8_t isSdCardInserted = 0;
    uint8_t ledYellowStatus = 0;
    uint8_t ledOrangeStatus = 0;
    uint8_t ledRedStatus = 0;

    uint8_t sendBuffer[20];
    memset(sendBuffer, 0, (sizeof(sendBuffer) / sizeof(uint8_t)));


    if (!isUseBuiltInSensorFusion)
    {
        readAccelerometerData(&accelData);

        sendBuffer[0] = (uint8_t) accelData.xAxisData;
        sendBuffer[1] = (uint8_t) (accelData.xAxisData >> 8);
        sendBuffer[2] = (uint8_t) accelData.yAxisData;
        sendBuffer[3] = (uint8_t) (accelData.yAxisData >> 8);
        sendBuffer[4] = (uint8_t) accelData.zAxisData;
        sendBuffer[5] = (uint8_t) (accelData.zAxisData >> 8);

        readGyroData(&gyroData);

        sendBuffer[6] = (uint8_t) gyroData.xAxisData;
        sendBuffer[7] = (uint8_t) (gyroData.xAxisData >> 8);
        sendBuffer[8] = (uint8_t) gyroData.yAxisData;
        sendBuffer[9] = (uint8_t) (gyroData.yAxisData >> 8);
        sendBuffer[10] = (uint8_t) gyroData.zAxisData;
        sendBuffer[11] = (uint8_t) (gyroData.zAxisData >> 8);
    }
    else
    {
        readRotationValue(&rotationData);

        memcpy(sendBuffer, (&rotationData.w), 4);
        memcpy(sendBuffer + 4, (&rotationData.x), 4);
        memcpy(sendBuffer + 8, (&rotationData.y), 4);
        memcpy(sendBuffer + 12, (&rotationData.z), 4);

#if DEBUG_LOGGING
        printf("rotationData w: %f \n", rotationData.w);
        printf("rotationData x: %f \n", rotationData.x);
        printf("rotationData y: %f \n", rotationData.y);
        printf("rotationData z: %f \n", rotationData.z);
#endif

    }
    ServiceInfo.sensorServicesContent = (uint8_t) HIGH_DATA_RATE_HIGH_PRIO;
    ServiceInfo.sensorServicesType = (uint8_t) BLE_HIGH_DATA_RATE;
    returnValue = SensorServices_SendData((uint8_t*) sendBuffer, 20, &ServiceInfo);
    if (RETCODE_OK == returnValue)
    {
        if (pdFALSE == xSemaphoreTake(SendCompleteSync, 1000))
        {
            printf("Ble data send event not received \r\n");
        }
    }
    else
    {
        printf("rotationData not send \n\r");
    }
    memset(sendBuffer, 0, (sizeof(sendBuffer) / sizeof(uint8_t)));
    if (sampleCounter % 2)
    {
#if DEBUG_LOGGING
        printf("message 1 \r\n");
#endif
        sendBuffer[0] = (uint8_t) 0x01; //message id 1

        readLightSensor(&milliLuxData);
        sendBuffer[1] = (uint8_t) (milliLuxData);
        sendBuffer[2] = (uint8_t) (milliLuxData >> 8);
        sendBuffer[3] = (uint8_t) (milliLuxData >> 16);
        sendBuffer[4] = (uint8_t) (milliLuxData >> 24);

        readNoiseSensor(&noiseDbSpl);
        sendBuffer[5] = noiseDbSpl;

        readEnvironmentSensor(&environmentData);
        sendBuffer[6] = (uint8_t) environmentData.pressure;
        sendBuffer[7] = (uint8_t) (environmentData.pressure >> 8);
        sendBuffer[8] = (uint8_t) (environmentData.pressure >> 16);
        sendBuffer[9] = (uint8_t) (environmentData.pressure >> 24);

        sendBuffer[10] = (uint8_t) environmentData.temperature;
        sendBuffer[11] = (uint8_t) (environmentData.temperature >> 8);
        sendBuffer[12] = (uint8_t) (environmentData.temperature >> 16);
        sendBuffer[13] = (uint8_t) (environmentData.temperature >> 24);

        sendBuffer[14] = (uint8_t) environmentData.humidity;
        sendBuffer[15] = (uint8_t) (environmentData.humidity >> 8);
        sendBuffer[16] = (uint8_t) (environmentData.humidity >> 16);
        sendBuffer[17] = (uint8_t) (environmentData.humidity >> 24);

        isSdCardInserted = readSdCardStatus();
        sendBuffer[18] = isSdCardInserted;

        sendBuffer[19] |= ((button1Status) << 0);
        sendBuffer[19] |= ((button2Status) << 1);

#if DEBUG_LOGGING
        printf("Button1 status: %i \r\n", button1Status);
        printf("Button2 status: %i \r\n", button2Status);
        printf("Button status send buffer: %i \r\n", sendBuffer[19]);

        printf("Sampling Rate: %d\r\n", (uint) highDataRateSampleTime);
#endif
    }
    else
    {
#if DEBUG_LOGGING
        printf("message 2 \r\n");
#endif

        sendBuffer[0] = (uint8_t) 0x02; //message id 2

        readMagnetometerSensor(&magData);
        sendBuffer[1] = (uint8_t) magData.xAxisData;
        sendBuffer[2] = (uint8_t) (magData.xAxisData >> 8);
        sendBuffer[3] = (uint8_t) magData.yAxisData;
        sendBuffer[4] = (uint8_t) (magData.yAxisData >> 8);
        sendBuffer[5] = (uint8_t) magData.zAxisData;
        sendBuffer[6] = (uint8_t) (magData.zAxisData >> 8);
        sendBuffer[7] = (uint8_t) (magData.resistance);
        sendBuffer[8] = (uint8_t) (magData.resistance >> 8);

        ledYellowStatus = GPIO_PinOutGet(LED_YELLOW_PORT, LED_YELLOW_PIN);
        ledOrangeStatus = GPIO_PinOutGet(LED_ORANGE_PORT, LED_ORANGE_PIN);
        ledRedStatus = GPIO_PinOutGet(LED_RED_PORT, LED_RED_PIN);

        sendBuffer[9] |= ((ledYellowStatus) << 0);
        sendBuffer[9] |= ((ledOrangeStatus) << 1);
        sendBuffer[9] |= ((ledRedStatus) << 2);

#if LEMSENSOR_ENABLE
        sendBuffer[14] = LemSensorStatus();
        /* If Lem sensor Connected then only populating the sensor values */
        if(true == sendBuffer[14])
        {
            returnValue = LemSensorGetRmsVoltage(&RMSVolt);
            if(RETCODE_OK != returnValue)
            {
                printf("Failed to get Lemsensor RMS voltage \r\n");
            }
            else
            {
                /* converting Volts to micro Volt */
                RmsuVolt =  (RMSVolt * VOLTS_TO_MICROVOLTS);
                sendBuffer[10] = RmsuVolt & 0xFF;
                sendBuffer[11] = (RmsuVolt >> 8) & 0xFF;
                sendBuffer[12] = (RmsuVolt >> 16) & 0xFF;
                sendBuffer[13] = (RmsuVolt >> 24) & 0xFF;
            }
        }
#endif

#if DEBUG_LOGGING
        printf("LedYellowStatus: %i \r\n", ledYellowStatus);
        printf("LedOrangeStatus: %i \r\n", ledOrangeStatus);
        printf("LedRedStatus: %i \r\n", ledRedStatus);

        printf("Led status send buffer: %i \r\n", sendBuffer[9]);
        printf("Current sensor Value %i %i %i %i \r\n", sendBuffer[13], sendBuffer[12], sendBuffer[11], sendBuffer[10]);
#endif
    }
    ServiceInfo.sensorServicesContent = (uint8_t) HIGH_DATA_RATE_LOW_PRIO;
    ServiceInfo.sensorServicesType = (uint8_t) BLE_HIGH_DATA_RATE;
    returnValue = SensorServices_SendData((uint8_t*) sendBuffer, 20, &ServiceInfo);
    if (RETCODE_OK == returnValue)
    {
        if (pdFALSE == xSemaphoreTake(SendCompleteSync, 1000))
        {
            printf("Ble data send event not received \r\n");
        }
    }
    sampleCounter++;
}

static Retcode_T magnetometerSensorInit(void)
{
    Retcode_T retVal = (Retcode_T) RETCODE_FAILURE;

    /*initialize Gyro sensor*/
    retVal = Magnetometer_init(xdkMagnetometer_BMM150_Handle);

    if (RETCODE_OK == retVal)
    {
        retVal = Magnetometer_setPowerMode(xdkMagnetometer_BMM150_Handle, MAGNETOMETER_BMM150_POWERMODE_NORMAL);
        if (RETCODE_OK != retVal)
        {
            printf("Error setting magnetormeter mode! \r\n");
        }
    }
    else
    {
        printf("Magnetometer_init failed! \r\n");
    }
    return retVal;
}

/** @brief Helper function to set registers when light sensor is initailized.
 *
 */
static Retcode_T setLightSensorRegisters(LightSensor_HandlePtr_T sensorHandle)
{
    Retcode_T retval = RETCODE_OK;

    /** Manual Mode should be enable in order to configure the continuous mode, brightness  and integration time*/
    retval = LightSensor_setManualMode(sensorHandle, LIGHTSENSOR_MAX44009_ENABLE_MODE);
    if (RETCODE_OK == retval)
    {
        retval = LightSensor_setIntegrationTime(sensorHandle, LIGHTSENSOR_100MS);
        if (RETCODE_OK == retval)
        {
            return (retval);
        }
        retval = LightSensor_setBrightness(sensorHandle, LIGHTSENSOR_HIGH_BRIGHTNESS);
        if (RETCODE_OK != retval)
        {
            printf("LightSensor_setBrightness failed \r\n");
            return (retval);
        }
    }
    else
    {
        printf("LightSensor_setManualMode failed !\r\n");
        return (retval);
    }
    retval = LightSensor_setContinuousMode(sensorHandle, LIGHTSENSOR_MAX44009_ENABLE_MODE);
    return (retval);
}

static void Button1Callback(uint32_t data)
{
    if ((int) BSP_XDK_BUTTON_PRESS == data)
    {
        button1Status = true;
    }
    else if ((int) BSP_XDK_BUTTON_RELEASE == data)
    {
        button1Status = false;
    }
}

static void Button2Callback(uint32_t data)
{
    if ((int) BSP_XDK_BUTTON_PRESS == data)
    {
        button2Status = true;
    }
    else if ((int) BSP_XDK_BUTTON_RELEASE == data)
    {
        button2Status = false;
    }
}

static Retcode_T ButtonInitialize(void)
{
    Retcode_T returnVal = RETCODE_OK;
    returnVal = BSP_Button_Connect();
    if (RETCODE_OK == returnVal)
    {
        returnVal = BSP_Button_Enable((uint32_t) BSP_XDK_BUTTON_1, Button1Callback);
    }
    if (RETCODE_OK == returnVal)
    {
        returnVal = BSP_Button_Enable((uint32_t) BSP_XDK_BUTTON_2, Button2Callback);
    }
    if (RETCODE_OK == returnVal)
    {
        printf("BUTTON Initialization success\r\n");
    }
    else
    {
        printf(" Error occurred in BUTTON Initialization routine %u \r\n", (unsigned int) returnVal);
    }

    return returnVal;
}
/**
 * @brief The function Enqueues sampleAndNotifyHighPriorityData to command processor
 *
 * @param[in] pvParameters Rtos task should be defined with the type void *(as argument)
 */
static void EnqueueHighPriorityData(void *pvParameters)
{

    BCDS_UNUSED(pvParameters);
    Retcode_T returnValue = RETCODE_OK;
    if (GetBleConnectionStatus() == BLE_PERIPHERAL_CONNECTED)
    {
        returnValue = CmdProcessor_enqueue(AppCmdProcessor, sampleAndNotifyHighPriorityData, NULL, UINT32_C(0));
        if (RETCODE_OK != returnValue)
        {
            printf("Enqueuing for sampleAndNotifyHighPriorityData  failed\n\r");
        }
    }
    else
    {
        printf("Device disconnected hence enqueue not done\n\r");
    }
}

/**
 * @brief The function Enqueues sampleAndNotifySensorData to command processor
 *
 * @param[in] pvParameters Rtos task should be defined with the type void *(as argument)
 */
#if !ENABLE_HIGH_PRIO_DATA_SERVICE
static void EnqueueSensorData(void *pvParameters)
{
    BCDS_UNUSED(pvParameters);
    Retcode_T returnValue = RETCODE_OK;
    if (GetBleConnectionStatus() == BLE_PERIPHERAL_CONNECTED)
    {
        returnValue = CmdProcessor_enqueue(AppCmdProcessor, sampleAndNotifySensorData, NULL, UINT32_C(0));
        if (RETCODE_OK != returnValue)
        {
            printf("Enqueuing for sampleAndNotifyHighPriorityData  failed\n\r");
        }
    }
    else
    {
        printf("Device disconnected hence enqueue not done\n\r");
    }
}
#endif

static Retcode_T BleInitialize(void)
{
    Retcode_T retVal = RETCODE_OK;
    BleStartSyncSemphr = xSemaphoreCreateBinary();
    if (NULL == BleStartSyncSemphr)
    {
        return (RETCODE(RETCODE_SEVERITY_FATAL, SEMAPHORE_CREATE_ERROR));
    }
    BleWakeUpSyncSemphr = xSemaphoreCreateBinary();
    if (NULL == BleWakeUpSyncSemphr)
    {
        return (RETCODE(RETCODE_SEVERITY_FATAL, SEMAPHORE_CREATE_ERROR));
    }
    /*Initialize the BLE sensor service receive and Transmit callback*/
    retVal = SensorServices_Init(BleDataReceivedCallBack, BleSendCallback);
    printf(retVal);
    if (RETCODE_OK == retVal)
    {
        retVal = BlePeripheral_Initialize(BleEventCallBack, SensorServiceRegistryCallback);
    }
    if (RETCODE_OK == retVal)
    {
        retVal = BlePeripheral_SetDeviceName((uint8_t*) VIRTUAL_XDK_BLE_DEVICE_NAME);
    }
    /* Powering on BLE module*/
    if (RETCODE_OK == retVal)
    {
        retVal = BlePeripheral_Start();
    }
    /* Powering on BLE module*/
    if (RETCODE_OK == retVal)
    {
        if (pdTRUE != xSemaphoreTake(BleStartSyncSemphr, BLE_START_SYNC_TIMEOUT))
        {
            printf("Failed to Start BLE before timeout, Ble Initialization failed \n");
            retVal = RETCODE(RETCODE_SEVERITY_ERROR, SEMAPHORE_TIME_OUT_ERROR);
        }
    }
    if (RETCODE_OK == retVal)
    {
        /* Wake up BLE module*/
        retVal = BlePeripheral_Wakeup();
    }
    if (RETCODE_OK == retVal)
    {
        if (pdTRUE != xSemaphoreTake(BleWakeUpSyncSemphr, BLE_WAKEUP_SYNC_TIMEOUT))
        {
            printf("Failed to Wake up BLE before timeout, Ble Initialization failed \n");
            retVal = RETCODE(RETCODE_SEVERITY_ERROR, SEMAPHORE_TIME_OUT_ERROR);
        }
    }
    if (RETCODE_OK == retVal)
    {
        printf("Ble initialized successfully \r\n");
    }
    else
    {
        printf("Ble initialization failed \r\n");
    }
    return retVal;
}

static Retcode_T SensorsInitialize(void)
{
    Retcode_T retval = RETCODE_OK;
#if NOISE_SENSOR_ACTIVATED
    noiseSensorInit();
#endif //NOISE_SENSOR_ACTIVATED
    retval = Accelerometer_init(xdkAccelerometers_BMA280_Handle);
    if (RETCODE_OK == retval)
    {
        retval = Gyroscope_init(xdkGyroscope_BMG160_Handle);
    }
    if (RETCODE_OK == retval)
    {
        retval = LightSensor_init(xdkLightSensor_MAX44009_Handle);
        if (RETCODE_OK == retval)
        {
            retval = setLightSensorRegisters(xdkLightSensor_MAX44009_Handle);
        }
    }
    if (RETCODE_OK == retval)
    {
        retval = magnetometerSensorInit();
    }
    if (RETCODE_OK == retval)
    {
        retval = Environmental_init(xdkEnvironmental_BME280_Handle);
    }
    if (RETCODE_OK == retval)
    {
        retval = Rotation_init(xdkRotationSensor_Handle);
    }

    if (RETCODE_OK == retval)
        {
            printf("SENSOR Initialization success\r\n");
        }
        else
        {
            printf(" Error occurred in SENSORS Initialization routine %u \r\n", (unsigned int) retval);
        }
    return retval;
}

/**
 * @brief Initialize the virtual XDK sensor sampling software module
 */
static void Init(void)
{
    Retcode_T retval = RETCODE_OK;
    static_assert((portTICK_RATE_MS != 0), "Tick rate MS is zero");

    SendCompleteSync = xSemaphoreCreateBinary();
    if(NULL == SendCompleteSync)
    {
        retval = RETCODE(RETCODE_SEVERITY_ERROR, SEMAPHORE_CREATE_ERROR);
    }
#if LEMSENSOR_ENABLE
    if (RETCODE_OK == retval)
    {
        retval = LemSensorInit();
    }
#endif
    if (RETCODE_OK == retval)
    {
        retval = BleInitialize();
    }
    if (RETCODE_OK == retval)
    {
        retval = SensorsInitialize();
    }
    if (RETCODE_OK == retval)
    {
        retval = ButtonInitialize();
    }
    if (RETCODE_OK == retval)
    {
        retval = SDCardDriver_Initialize();
    }

#if !ENABLE_HIGH_PRIO_DATA_SERVICE
    if(RETCODE_OK == retval)
    {
        /* create timer task to read sensor data automatically (every Ticks) and write into the attribute database*/
        sensorSampleTimerHandle = xTimerCreate((char * const ) "sampleSensorData", pdMS_TO_TICKS(sensorSampleTime), TIMER_AUTORELOAD_ON, NULL, EnqueueSensorData);

        if((RETCODE_OK != retval) && (NULL == sensorSampleTimerHandle))
        {
            printf("Sensor characteristic Timer failed to create!\r\n");
            assert(false);
        }
        /*start the created timer*/
        if(pdPASS != xTimerStart(sensorSampleTimerHandle, TIMERBLOCKTIME))
        {
            printf("Sensor characteristic Timer failed to start!\r\n");
            assert(false);
        }
    }
#endif
    if (RETCODE_OK == retval)
    {
        /* create timer task to read all sensor data every defined sample time automatically and write into the attribute database*/
        highDataRateSampleTimerHandle = xTimerCreate((char * const ) "sampleHighPriorityData", pdMS_TO_TICKS(highDataRateSampleTime), TIMER_AUTORELOAD_ON, NULL, EnqueueHighPriorityData);

        if (NULL == highDataRateSampleTimerHandle)
        {
            printf("High data rate sample Timer failed to create!\r\n");
            assert(false);
        }
    }
    else
    {
        printf("App not started due to initialization fail!\r\n");
        assert(false);
    }
}

/* global functions ********************************************************* */

void appInitSystem(void * CmdProcessorHandle, uint32_t param2)
{
    BCDS_UNUSED(param2);
    if (CmdProcessorHandle == NULL)
    {
        printf("Command processor handle is null \n\r");
        assert(false);
    }
    /* Delay required for the USB to enumerate */
    BSP_Board_Delay(1000);
    AppCmdProcessor = (CmdProcessor_T*) CmdProcessorHandle;
    Init();
}

#if IMPLEMENTATION_ENHANCEMENT
/**
 * @brief Deinitialize the virtual XDK sensor sampling software module
 */
static void Deinitialize(void)
{
    /* Return value from Sensors */
    Retcode_T returnValue = (Retcode_T) RETCODE_FAILURE;

    /* Initialize sensors */
    returnValue = Accelerometer_deInit(xdkAccelerometers_BMA280_Handle);
    if (RETCODE_OK == returnValue)
    {
        returnValue = Gyroscope_deInit(xdkGyroscope_BMG160_Handle);
    }
    if (RETCODE_OK == returnValue)
    {
        returnValue = LightSensor_deInit(xdkLightSensor_MAX44009_Handle);
    }
    if (RETCODE_OK == returnValue)
    {
        returnValue = Rotation_deInit();
    }
    if (RETCODE_OK == returnValue)
    {
        returnValue = Magnetometer_deInit(xdkMagnetometer_BMM150_Handle);
    }
    if (RETCODE_OK == returnValue)
    {
        returnValue = Environmental_deInit(xdkEnvironmental_BME280_Handle);
    }
    if (RETCODE_OK == returnValue)
    {
        printf("De-initializing of all sensors was succesful! \r\n");
    }
    else
    {
        printf("unable to De-initialize of all sensors ! \r\n");
    }
}

#endif

/**@} */
/** ************************************************************************* */
